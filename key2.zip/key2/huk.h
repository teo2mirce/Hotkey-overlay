#include <Windows.h>
#include <iostream>
#include <stdio.h>
#include <stdlib.h>
using namespace std;

wxString whatToShow;
int timy=0;
int eBine=true;

class MyHook{
public:
	//single ton
	static MyHook& Instance(){
	    //whatToShow="";
		static MyHook myHook;
		return myHook;
	}
	HHOOK hook1; // handle to the hook
	HHOOK hook2; // handle to the hook
	void InstallHook(); // function to install our hook
	void UninstallHook(); // function to uninstall our hook

	MSG msg; // struct with information about all messages in our queue
	int Messsages(); // function to "deal" with our messages
};
LRESULT WINAPI MyMouseCallback(int nCode, WPARAM wParam, LPARAM lParam); //callback declaration
LRESULT WINAPI MyKeyCallback(int nCode, WPARAM wParam, LPARAM lParam); //callback declaration
int MyHook::Messsages(){


	//while (msg.message != WM_QUIT){ //while we do not close our application
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)){
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		Sleep(10);
	//}
}
void MyHook::InstallHook(){
	/*
	SetWindowHookEx(
	WM_MOUSE_LL = mouse low level hook type,
	MyMouseCallback = our callback function that will deal with system messages about mouse
	NULL, 0);

	c++ note: we can check the return SetWindowsHookEx like this because:
	If it return NULL, a NULL value is 0 and 0 is false.
	*/
	if (!(hook1 = SetWindowsHookEx(WH_MOUSE_LL, MyMouseCallback, NULL, 0)))
		printf("Error: %x \n", GetLastError());
	if (!(hook2 = SetWindowsHookEx(WH_KEYBOARD_LL, MyKeyCallback, NULL, 0)))
		printf("Error: %x \n", GetLastError());
}
void MyHook::UninstallHook(){
	/*
	uninstall our hook using the hook handle
	*/
	//UnhookWindowsHookEx(hook1);
	//UnhookWindowsHookEx(hook2);
}
int DD = GetDoubleClickTime();

unsigned long L,M,R;
unsigned long LU,MU,RU;
unsigned long LX,LY,MX,MY,RX,RY;
LRESULT WINAPI MyMouseCallback(int nCode, WPARAM wParam, LPARAM lParam){
	MSLLHOOKSTRUCT * pMouseStruct = (MSLLHOOKSTRUCT *)lParam; // WH_MOUSE_LL struct
	if (nCode == 0)	{ // we have information in wParam/lParam ? If yes, let's check it:


        wxString ichar="";
        if(GetAsyncKeyState(VK_CONTROL))
            ichar<<"Ctrl + ";
        if(GetAsyncKeyState(VK_MENU))
            ichar<<"Alt + ";
        if(GetAsyncKeyState(VK_SHIFT))
            ichar<<"Shift + ";
        if(GetAsyncKeyState(VK_LWIN) || GetAsyncKeyState(VK_RWIN))
            ichar<<"Win + ";


		if (pMouseStruct != NULL){ // Mouse struct contain information?
			printf("Mouse Coordinates: x = %i | y = %i \n", pMouseStruct->pt.x, pMouseStruct->pt.y);

			if(L>LU && pMouseStruct->pt.x!=LX && pMouseStruct->pt.y!=LY && ichar.IsEmpty()==false)
                whatToShow=ichar+"Drag",timy=clock(),eBine=false;
			if(M>MU && pMouseStruct->pt.x!=MX && pMouseStruct->pt.y!=MY)
                whatToShow=ichar+"Drag Middle",timy=clock(),eBine=false;
			if(R>RU && pMouseStruct->pt.x!=RX && pMouseStruct->pt.y!=RY)
                whatToShow=ichar+"Drag Right",timy=clock(),eBine=false;

		}
		switch (wParam){
        case WM_LBUTTONDBLCLK:
            wxMessageBox("double click");break;
		//case WM_LBUTTONUP:printf("LEFT CLICK UP\n");break;
		case WM_MBUTTONDOWN:
		    if(clock()-M<DD && pMouseStruct->pt.x==MX && pMouseStruct->pt.y==MY)
                whatToShow=ichar+"Double Click Middle",timy=clock(),eBine=false;
            else
                whatToShow=ichar+"Click Middle",timy=clock(),eBine=false;
		    M=clock();MX=pMouseStruct->pt.x;MY=pMouseStruct->pt.y;break;
		case WM_LBUTTONDOWN:
		    if(clock()-L<DD && pMouseStruct->pt.x==LX && pMouseStruct->pt.y==LY)
                whatToShow=ichar+"Double Click",timy=clock(),eBine=false;
            else
                if(ichar.IsEmpty()==false)
                    whatToShow=ichar+"Click",timy=clock(),eBine=false;
                L=clock();LX=pMouseStruct->pt.x;LY=pMouseStruct->pt.y;break;
		case WM_RBUTTONDOWN:
		    if(clock()-R<DD && pMouseStruct->pt.x==RX && pMouseStruct->pt.y==RY)
                whatToShow=ichar+"Double Click Right",timy=clock(),eBine=false;
            else
                if(ichar.IsEmpty()==false)
                    whatToShow=ichar+"Click Right",timy=clock(),eBine=false;
            R=clock();RX=pMouseStruct->pt.x;RY=pMouseStruct->pt.y;break;

        case WM_MBUTTONUP:MU=clock();break;
        case WM_LBUTTONUP:LU=clock();break;
        case WM_RBUTTONUP:RU=clock();break;

		case WM_MOUSEWHEEL:
            timy=clock();
		    if ((short)HIWORD(pMouseStruct->mouseData) > 0)
                whatToShow=ichar+"Mouse Wheel Up",eBine=false;
            if ((short)HIWORD(pMouseStruct->mouseData) < 0)
                whatToShow=ichar+"Mouse Wheel Down",eBine=false;
		    break;
		}
	}
	sf:;
	return CallNextHookEx(MyHook::Instance().hook1, nCode, wParam, lParam);
}
 int FocusedControlInActiveWindow()
{

    GUITHREADINFO guiThreadInfoObject;
    guiThreadInfoObject.cbSize=sizeof(GUITHREADINFO);
    DWORD tid = GetWindowThreadProcessId(GetForegroundWindow(),0);
    if(GetGUIThreadInfo(tid,&guiThreadInfoObject))
        if(guiThreadInfoObject.flags && GUI_CARETBLINKING)
            return 1;
        return 0;
}

LRESULT WINAPI MyKeyCallback(int nCode, WPARAM wParam, LPARAM lParam){
	KBDLLHOOKSTRUCT * pMouseStruct = (KBDLLHOOKSTRUCT *)lParam; // WH_MOUSE_LL struct
	if (nCode == 0)	{ // we have information in wParam/lParam ? If yes, let's check it:

        if(pMouseStruct->vkCode==VK_RSHIFT || pMouseStruct->vkCode==VK_LSHIFT ||
        pMouseStruct->vkCode==VK_LCONTROL || pMouseStruct->vkCode==VK_RCONTROL ||
        pMouseStruct->vkCode==VK_LMENU || pMouseStruct->vkCode==VK_RMENU ||
        pMouseStruct->vkCode==VK_LWIN || pMouseStruct->vkCode==VK_RWIN)
            {
                return CallNextHookEx(MyHook::Instance().hook2, nCode, wParam, lParam);
            }
		if (wParam == WM_KEYDOWN){

        wxString ichar="";
        if(GetAsyncKeyState(VK_CONTROL))
            ichar<<"Ctrl + ",timy=clock();
        if(GetAsyncKeyState(VK_CONTROL) || GetAsyncKeyState(VK_SHIFT) || GetAsyncKeyState(VK_LWIN) || GetAsyncKeyState(VK_RWIN))
            if(GetAsyncKeyState(VK_MENU))
                ichar<<"Alt + ",timy=clock();
        if(GetAsyncKeyState(VK_SHIFT))
            ichar<<"Shift + ",timy=clock();
        if(GetAsyncKeyState(VK_LWIN) || GetAsyncKeyState(VK_RWIN))
            ichar<<"Win + ",timy=clock();



        if(pMouseStruct->vkCode==VK_RETURN && pMouseStruct->flags){whatToShow=ichar + "Enter";eBine=false,timy=clock();;goto iesi;}
        if(pMouseStruct->vkCode==VK_RETURN  ){whatToShow=ichar + "Return";eBine=false,timy=clock();;goto iesi;}
        if(pMouseStruct->vkCode==VK_OEM_3  ){whatToShow=ichar + "Tilda (~)";eBine=false,timy=clock();;goto iesi;}


            TCHAR lpszName[256];
            DWORD dwMsg = 1;

            dwMsg += pMouseStruct->scanCode << 16;
            dwMsg += pMouseStruct->flags << 24;
            int i = GetKeyNameText(dwMsg , lpszName, 255);

            wxString hue="";
            hue<<ichar<<lpszName;

            if(FocusedControlInActiveWindow()==1 && hue.length()==1)
                return CallNextHookEx(MyHook::Instance().hook2, nCode, wParam, lParam);

            timy=clock();
            if(eBine==false)
                whatToShow="";

            if(hue.length()==1 || (eBine==true && pMouseStruct->vkCode==VK_SPACE && whatToShow.length()>0))
                eBine=true;
            else
            {
                eBine=false;
                whatToShow="";
            }


            if(eBine)
            {
                if(hue.length()==1)
                    whatToShow+=hue;
                if(pMouseStruct->vkCode==VK_SPACE)
                    whatToShow+=" ";
                    goto iesi;
            }
            whatToShow=ichar +  lpszName;
            eBine=false;


		}
	}
	iesi:;
	return CallNextHookEx(MyHook::Instance().hook2, nCode, wParam, lParam);
}
